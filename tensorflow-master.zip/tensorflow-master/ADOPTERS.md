# TensorFlow Adopters

This page contains a list of people and organizations who are using TensorFlow. If you'd like to be included
here, please send a pull request which modifies this file.

We intend to use this list to contact you for surveys, and to find good candidates for invite-only events. 
We will also point to this list if we are asked who uses TensorFlow.

We will not use any of the information here for promotions or to send other regular communications. You 
should subscribe to discuss@tensorflow.org for such announcements.
